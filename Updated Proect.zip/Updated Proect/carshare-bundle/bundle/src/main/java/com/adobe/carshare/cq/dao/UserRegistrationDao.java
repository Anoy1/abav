package com.adobe.carshare.cq.dao;

import com.adobe.carshare.cq.RestExchangeUtility;
import com.adobe.carshare.cq.dtos.Users;
import com.adobe.carshare.cq.impl.RestExchangeUtilityImpl;
import org.apache.felix.scr.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class UserRegistrationDao {
    Logger log = LoggerFactory.getLogger(this.getClass());

    RestExchangeUtility restExchangeUtility = new RestExchangeUtilityImpl();

    public  String reserveUser(Users user){
        log.info("Inside Dao");
        String response ="";
        try {
            response =restExchangeUtility.makeApostCall("http://localhost:8080/registerUserDetails",user);
            log.info("response is  {}",response);
        } catch (IOException e) {

        }

        return response;
    }
}
