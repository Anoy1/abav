package com.adobe.carshare.cq.dtos;


public class Location {
    private String locationCode;
    private String locationName;
    private String locationDesc;


    public Location() {
    }

    public Location(String locationCode, String locationName, String locationDesc) {
        this.locationCode = locationCode;
        this.locationName = locationName;
        this.locationDesc = locationDesc;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getLocationDesc() {
        return locationDesc;
    }

    public void setLocationDesc(String locationDesc) {
        this.locationDesc = locationDesc;
    }
}
