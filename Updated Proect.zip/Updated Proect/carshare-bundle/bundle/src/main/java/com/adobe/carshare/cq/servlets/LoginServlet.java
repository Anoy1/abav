package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.services.LoginService;
import com.adobe.carshare.cq.services.LoginServiceImpl;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import javax.servlet.ServletException;
import java.io.IOException;

@SlingServlet(paths="/bin/validateLogin")
public class LoginServlet extends SlingSafeMethodsServlet {
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        LoginService loginService = new LoginServiceImpl();
        String responseMsg = loginService.validateLogin(email,password);
        response.getWriter().println(responseMsg);

    }
}
