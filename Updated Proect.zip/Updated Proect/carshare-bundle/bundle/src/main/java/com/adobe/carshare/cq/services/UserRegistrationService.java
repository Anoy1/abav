package com.adobe.carshare.cq.services;

import com.adobe.carshare.cq.dtos.Users;

public interface UserRegistrationService {
    public String reserveUser(Users user);
}
