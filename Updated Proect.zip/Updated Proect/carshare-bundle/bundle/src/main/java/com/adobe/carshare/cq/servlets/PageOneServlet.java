package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.dtos.Location;
import com.adobe.carshare.cq.dtos.Reservation;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
@SlingServlet(paths="/bin/savePageOne")
public class PageOneServlet extends SlingAllMethodsServlet {
    Logger log = LoggerFactory.getLogger(this.getClass());
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        log.info("Inside PageOneServlet - {}");
        String pickupLocation  = request.getParameter("pickupLocation");
        Date pickUpDate=null;
        try {
            pickUpDate = new SimpleDateFormat("yyyy-mm-dd").parse(request.getParameter("pickUpDate"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String dropLocation  = request.getParameter("dropLocation");
        Date dropDate=null;
        try {
            dropDate = new SimpleDateFormat("yyyy-mm-dd").parse(request.getParameter("dropDate"));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Reservation reservationPageOne = new Reservation();
        String[] pickuPLocArray = pickupLocation.split("~");
        Location pickupLocationObj = new Location(pickuPLocArray[0],pickuPLocArray[1],pickuPLocArray[2]);

        String[] dropLocArray = dropLocation.split("~");
        Location dropLocationObj = new Location(dropLocArray[0],dropLocArray[1],dropLocArray[2]);

        reservationPageOne.setPickupLocation(pickupLocationObj);
        reservationPageOne.setPickUpTime(pickUpDate);
        reservationPageOne.setDropLocation(dropLocationObj);
        reservationPageOne.setDropTime(dropDate);
        log.info("inside Pageone Sevlet before redirecting with reservatin object -{}",reservationPageOne);

        request.setAttribute("reservationPageOne",reservationPageOne);
        HttpSession session = request.getSession();
        session.setAttribute("currentReservation",reservationPageOne);
        RequestDispatcher rd = request.getRequestDispatcher("/content/carshare-app/registrationlanding/choosevehicle.html");
        log.info("Before forwarding to chhose vehicle");
        rd.forward(request,response);


    }
}
