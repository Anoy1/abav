package com.adobe.carshare.cq.dtos;


import java.util.Date;

public class Reservation {
    private Location pickupLocation;
    private Location dropLocation;
    private Date pickUpTime;
    private Date dropTime;
    private Vehicle selectedVehicle;
    private RatePlan associatedRatePlan;
    private Users customer;
    private CustomerAddress address;

    public Reservation() {
    }

    public Location getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(Location pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public Location getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(Location dropLocation) {
        this.dropLocation = dropLocation;
    }

    public Date getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(Date pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public Date getDropTime() {
        return dropTime;
    }

    public void setDropTime(Date dropTime) {
        this.dropTime = dropTime;
    }

    public Vehicle getSelectedVehicle() {
        return selectedVehicle;
    }

    public void setSelectedVehicle(Vehicle selectedVehicle) {
        this.selectedVehicle = selectedVehicle;
    }

    public RatePlan getAssociatedRatePlan() {
        return associatedRatePlan;
    }

    public void setAssociatedRatePlan(RatePlan associatedRatePlan) {
        this.associatedRatePlan = associatedRatePlan;
    }

    public Users getCustomer() {
        return customer;
    }

    public void setCustomer(Users customer) {
        this.customer = customer;
    }

    public CustomerAddress getAddress() {
        return address;
    }

    public void setAddress(CustomerAddress address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "pickupLocation=" + pickupLocation +
                ", dropLocation=" + dropLocation +
                ", pickUpTime=" + pickUpTime +
                ", dropTime=" + dropTime +
                ", selectedVehicle=" + selectedVehicle +
                ", associatedRatePlan=" + associatedRatePlan +
                ", customer=" + customer +
                ", address=" + address +
                '}';
    }
}
