package com.adobe.carshare.cq;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimpleUnitTest {

    @Test
    public void someTest() {
        assertTrue(true);
    }

}