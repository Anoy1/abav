insert into location values('KOL','East India','Kolkata');
insert into location values('CHN','South India','Chennai');
insert into location values('PUN','North India','Punjab');
insert into location values('GUJ','West India','Gujrat');

insert into vehicle values('HC',true,true,4,'honda city','sedan','KOL');
insert into vehicle values('EON',false,false,4,'Hyundai EOn','hatchback','KOL');


Insert into RATE_PLAN values (1,'$', 8,'USSED','Sedan for US','KOL','HC');
Insert into RATE_PLAN values (2,'INR',70,'INHB','HatchBack India','CHN','EON');
