package org.carshare.restapi.services.jparepositories;

import org.carshare.restapi.services.modell.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation,Long> {
    List<Reservation> findByCustomer_Email(String email);
    List<Reservation> findByPickUpTimeAfter(Date pickUpTime);
    List<Reservation> findByDropTimeBefore(Date dropTime);

}
