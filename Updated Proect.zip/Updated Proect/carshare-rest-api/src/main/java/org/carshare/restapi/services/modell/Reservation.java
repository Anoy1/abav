package org.carshare.restapi.services.modell;

import org.carshare.restapi.services.modell.nonentity.CustomerAddress;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long reservationConfirmationID;
    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "pickup_location_code")
    private Location pickupLocation;
    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "drop_location_code")
    private Location dropLocation;
    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    private Date pickUpTime;
    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    @Future
    private Date dropTime;

    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "selected_vehicle_code")
    private Vehicle selectedVehicle;

    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "assoc_rate_plan_code")
    private RatePlan associatedRatePlan;
    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "registered_user_id")
    private Users customer;
    @Embedded
    private CustomerAddress address;

    public Reservation() {
    }

    public long getReservationConfirmationID() {
        return reservationConfirmationID;
    }

    public void setReservationConfirmationID(long reservationConfirmationID) {
        this.reservationConfirmationID = reservationConfirmationID;
    }

    public Location getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(Location pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public Location getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(Location dropLocation) {
        this.dropLocation = dropLocation;
    }

    public Date getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(Date pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public Date getDropTime() {
        return dropTime;
    }

    public void setDropTime(Date dropTime) {
        this.dropTime = dropTime;
    }

    public Vehicle getSelectedVehicle() {
        return selectedVehicle;
    }

    public void setSelectedVehicle(Vehicle selectedVehicle) {
        this.selectedVehicle = selectedVehicle;
    }

    public RatePlan getAssociatedRatePlan() {
        return associatedRatePlan;
    }

    public void setAssociatedRatePlan(RatePlan associatedRatePlan) {
        this.associatedRatePlan = associatedRatePlan;
    }

    public Users getCustomer() {
        return customer;
    }

    public void setCustomer(Users customer) {
        this.customer = customer;
    }

    public CustomerAddress getAddress() {
        return address;
    }

    public void setAddress(CustomerAddress address) {
        this.address = address;
    }
}
