package org.carshare.restapi.services.controller;

import org.carshare.restapi.services.jparepositories.VehicleRepository;
import org.carshare.restapi.services.modell.Vehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class VehicleController {
    Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    VehicleRepository vehicleRepository;

    @GetMapping("/getAllVehicles/{locationCode}")
    public ResponseEntity<List<Vehicle>> getAllVehiclesForLocation(@PathVariable String locationCode) {
        List<Vehicle> allVehiclesForLocation = vehicleRepository.findByLocation_LocationCode(locationCode);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
       // log.info("For Location - {} , Vehicle List is - {}", locationCode, allVehiclesForLocation);
        return (allVehiclesForLocation.size() != 0 ? new ResponseEntity<>(allVehiclesForLocation, headers,HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

}
