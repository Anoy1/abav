package com.adobe.carshare.cq.services;

public interface LoginService {
    public String validateLogin(String email, String password);
}
