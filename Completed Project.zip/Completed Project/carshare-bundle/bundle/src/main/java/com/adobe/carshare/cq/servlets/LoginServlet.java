package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.dtos.Users;
import com.adobe.carshare.cq.services.LoginService;
import com.adobe.carshare.cq.services.LoginServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.IOException;
import java.text.SimpleDateFormat;

@SlingServlet(paths = "/bin/validateLogin")
public class LoginServlet extends SlingSafeMethodsServlet {
    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        LoginService loginService = new LoginServiceImpl();
        String responseMsg = loginService.validateLogin(email, password);
        RequestDispatcher rd = null;
        if (responseMsg.contains("{")) {
            ObjectMapper objectMapper = new ObjectMapper();
            Users loggedInUser = objectMapper.readValue(responseMsg, Users.class);
            SimpleDateFormat sd = new SimpleDateFormat("yyyy-mm-dd");
            String dob= sd.format(loggedInUser.getDateOfBirth());
            String logInreqAttribute="userID="+loggedInUser.getUserID()+"&fullName="+loggedInUser.getFullName()+"&email="+loggedInUser.getEmail()+"&DL="+loggedInUser.getDriverLicense()+"&pwd="+loggedInUser.getPassword()+"&dob="+dob;
            request.setAttribute("loggedinUser",logInreqAttribute);
            request.setAttribute("loggedinUserObj",loggedInUser);
            rd = request.getRequestDispatcher("/content/carshare-app/registrationlanding.html");
        } else {
            //request.setAttribute("errMsg", "Invalid Credentials");
            rd = request.getRequestDispatcher("/content/carshare-app.html?errMsg=Invalid Credentials");
        }
        rd.forward(request, response);
       // response.getWriter().println(responseMsg);

    }
}
