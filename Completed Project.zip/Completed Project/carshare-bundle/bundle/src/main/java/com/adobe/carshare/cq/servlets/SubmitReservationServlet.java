package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.dtos.*;
import com.adobe.carshare.cq.services.MakeReservation;
import com.adobe.carshare.cq.services.MakeReservationImpl;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by 298625 on 4/9/2019.
 */

@SlingServlet(paths = "/bin/saveRenterInfo")
public class SubmitReservationServlet extends SlingAllMethodsServlet {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        log.info("Inside Submit Reservation Servlet@#################################################");
        String pickupLocation = request.getParameter("pickuplocationObjString");
        String pickUpDate = request.getParameter("pickUpDate");
        String droplocationObjString = request.getParameter("droplocationObjString");
        String dropDate = request.getParameter("dropDate");
        String loggedInUser = request.getParameter("loggedInUser");
        String selectedVehicleRowData = request.getParameter("selectedVehicleRowData");
        String selectedRatePlanData = request.getParameter("selectedRatePlanData");

        String addressLine1 = request.getParameter("addressLine1");
        String addressLine2 = request.getParameter("addressLine2");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zipCode = request.getParameter("zipCode");
        String country = request.getParameter("country");
        String phoneNumber = request.getParameter("phoneNumber");


        log.info("Inside Submit Reservation Servlet pickupLocation is {}", pickupLocation);
        log.info("Inside Submit Reservation Servlet pickUpDate is {}", pickUpDate);
        log.info("Inside Submit Reservation Servlet droplocationObjString is {}", droplocationObjString);
        log.info("Inside Submit Reservation Servlet dropDate is {}", dropDate);
        log.info("Inside Submit Reservation Servlet loggedInUser is {}", loggedInUser);
        log.info("Inside Submit Reservation Servlet selectedVehicleRowData is {}", selectedVehicleRowData);
        log.info("Inside Submit Reservation Servlet selectedRatePlanData is {}", selectedRatePlanData);
        SimpleDateFormat sd = new SimpleDateFormat("yyyy-mm-dd");

        Reservation reservation = new Reservation();
        String pickupLocationArrary[] = pickupLocation.split("~");
        String droplocationArray[] = droplocationObjString.split("~");
        Location pickupLocationReserved = new Location(pickupLocationArrary[0], pickupLocationArrary[1], pickupLocationArrary[2]);
        Location dropLocationReserved = new Location(droplocationArray[0], droplocationArray[1], droplocationArray[2]);
        reservation.setPickupLocation(pickupLocationReserved);
        reservation.setDropLocation(dropLocationReserved);
        Date pickupTime = null;
        try {
            pickupTime = sd.parse(pickUpDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        reservation.setPickUpTime(pickupTime);

        Date dropTime = null;
        try {
            dropTime = sd.parse(dropDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        reservation.setDropTime(pickupTime);

        CustomerAddress customerAddress = new CustomerAddress();
        customerAddress.setAddressLine1(addressLine1);
        customerAddress.setAddressLine2(addressLine2);
        customerAddress.setCity(city);
        customerAddress.setState(state);
        customerAddress.setZipCode(zipCode);
        customerAddress.setCountry(country);
        customerAddress.setPhoneNumber(phoneNumber);
        reservation.setAddress(customerAddress);

        String[] selectedVehicle = selectedVehicleRowData.split("~");
        Vehicle selectedVehicleForReservation = new Vehicle();
        selectedVehicleForReservation.setVehicleCode(selectedVehicle[0]);
        selectedVehicleForReservation.setVehicleType(selectedVehicle[1]);
        selectedVehicleForReservation.setVehicleName(selectedVehicle[2]);
        selectedVehicleForReservation.setNoOfSeats(Integer.parseInt(selectedVehicle[3]));
        selectedVehicleForReservation.setAirBagSafety(Boolean.valueOf(selectedVehicle[4]));
        selectedVehicleForReservation.setGpsEnabled(Boolean.valueOf(selectedVehicle[5]));

        reservation.setSelectedVehicle(selectedVehicleForReservation);


        String[] assocRatePlanArray = selectedRatePlanData.split("~");

        RatePlan assocRatePlanForReservation = new RatePlan();
        assocRatePlanForReservation.setRateId(Integer.parseInt(assocRatePlanArray[0]));
        assocRatePlanForReservation.setRateCode(assocRatePlanArray[1]);
        assocRatePlanForReservation.setRatePlanName(assocRatePlanArray[2]);
        assocRatePlanForReservation.setCurrency(assocRatePlanArray[3]);
        assocRatePlanForReservation.setHourlyRate(Long.parseLong(assocRatePlanArray[4]));
        assocRatePlanForReservation.setLocation(pickupLocationReserved);
        assocRatePlanForReservation.setVehicle(selectedVehicleForReservation);

        reservation.setAssociatedRatePlan(assocRatePlanForReservation);
        Users users = new Users();
        String loggedUserDetails[] = loggedInUser.split("&");
        for (String userAttr : loggedUserDetails) {
            String[] kv = userAttr.split("=");
            if ("userID".equalsIgnoreCase(kv[0])) {
                users.setUserID(Integer.parseInt(kv[1]));
            } else if ("fullName".equalsIgnoreCase(kv[0])) {
                users.setFullName(kv[1]);
            } else if ("email".equalsIgnoreCase(kv[0])) {
                users.setEmail(kv[1]);
            } else if ("DL".equalsIgnoreCase(kv[0])) {
                users.setDriverLicense(kv[1]);
            } else if ("pwd".equalsIgnoreCase(kv[0])) {
                users.setPassword(kv[1]);
            } else if ("dob".equalsIgnoreCase(kv[0])) {
                Date dob = null;
                try {
                    dob = sd.parse(kv[1]);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                users.setDateOfBirth(dob);

            }


        }
        reservation.setCustomer(users);

        log.info("Posting Reservation Details --- {}",reservation);
        MakeReservation makeReservation = new MakeReservationImpl();
        String responseMsg = makeReservation.reserveVehicle(reservation);
        /*request.setAttribute("reservationStatus","Reservation Successful");
        request.setAttribute("reservationResponse",responseMsg);*/

        RequestDispatcher rd = request.getRequestDispatcher("/content/carshare-app/showreservation.html");
        rd.forward(request,response);
       // response.getWriter().println("Hurrah!!!!!!!!!!!!!!!"+responseMsg);

    }


}
