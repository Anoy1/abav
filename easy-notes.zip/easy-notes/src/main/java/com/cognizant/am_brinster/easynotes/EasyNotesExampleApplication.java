package com.cognizant.am_brinster.easynotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class EasyNotesExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasyNotesExampleApplication.class, args);
	}

}
