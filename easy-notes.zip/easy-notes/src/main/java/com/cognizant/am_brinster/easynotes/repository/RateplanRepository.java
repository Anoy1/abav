package com.cognizant.am_brinster.easynotes.repository;

import com.cognizant.am_brinster.easynotes.entity.RatePlan;
import com.cognizant.am_brinster.easynotes.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RateplanRepository extends JpaRepository<RatePlan,Long> {

    @Query(
            value = "SELECT rate_plan_id,rate_per_hour FROM hibernatesample.rate_plan r WHERE r.location_code = ?1 and r.vehicle_id=?2",
            nativeQuery = true)
    Object[] findRatePlansByLocationCodeAndVehicle(String locationCode,String vehicleID);
}



