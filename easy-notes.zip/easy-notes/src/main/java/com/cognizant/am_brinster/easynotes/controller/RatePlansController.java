package com.cognizant.am_brinster.easynotes.controller;

import com.cognizant.am_brinster.easynotes.repository.RateplanRepository;
import com.cognizant.am_brinster.easynotes.repository.VehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RestController
public class RatePlansController {

    Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    RateplanRepository rateplanRepository;
    @GetMapping("/getRatePlansFor/{locationCode}/{vehicleID}")
    public List getVehicleForLocation(@PathVariable("locationCode") String locationCode,@PathVariable("vehicleID") String vehicleID){
        log.info("xxx locationCode ==== > "+locationCode);
        log.info("xxx vehicleID ==== > "+vehicleID);
        //Location location = new Location(locationCode);
        Object[] listOfRatePlansObject =rateplanRepository.findRatePlansByLocationCodeAndVehicle(locationCode,vehicleID);
        if(listOfRatePlansObject!=null){
            return Arrays.asList(listOfRatePlansObject);
        }else{
            return  null;
        }

    }
}
