package com.cognizant.am_brinster.easynotes.repository;

import com.cognizant.am_brinster.easynotes.entity.Location;
import com.cognizant.am_brinster.easynotes.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface VehicleRepository extends JpaRepository<Vehicle,Long> {
    @Query(
            value = "SELECT vehicleid,vehicle_name,vehicle_description FROM hibernatesample.vehicle v WHERE v.location_code = ?1",
            nativeQuery = true)
    Object[] findVehiclesByLocationCode(String locationCode);

}
