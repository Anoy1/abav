package com.cognizant.am_brinster.easynotes.repository;

import com.cognizant.am_brinster.easynotes.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface LocationRepository extends JpaRepository<Location,String> {

    @Query(
            value = "SELECT location_code,location_name FROM hibernatesample.location_master v ",
            nativeQuery = true)
    Object[] findAllLocations();

}
