package com.cognizant.am_brinster.easynotes.entity;

import javax.persistence.*;

@Entity
public class RatePlan {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int ratePlanId;
    @OneToOne
    @JoinColumn(name = "LocationCode")
    private Location location;
    @OneToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;
    @Column(name = "ratePerHour")
    private int ratePerHour;

    public RatePlan() {
    }

    public RatePlan(int ratePlanId, Location location, Vehicle vehicle, int ratePerHour) {
        this.ratePlanId = ratePlanId;
        this.location = location;
        this.vehicle = vehicle;
        this.ratePerHour = ratePerHour;
    }

    public int getRatePlanId() {
        return ratePlanId;
    }

    public void setRatePlanId(int ratePlanId) {
        this.ratePlanId = ratePlanId;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public int getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(int ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
}
