package com.cognizant.am_brinster.easynotes.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Location_Master")
public class Location {
    @Id
    @Column(name = "LocationCode")
    private String locationCode;
    @Column(name = "LocationName")
    private String locationName;

    @OneToMany(mappedBy = "location")
    private List<Vehicle> listOfvehicles;
    @OneToOne(mappedBy = "location")
    private RatePlan ratePlan;


    public Location() {
    }



    public Location(String locationCode, String locationName) {
        this.locationCode = locationCode;
        this.locationName = locationName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public List<Vehicle> getListOfvehicles() {
        return listOfvehicles;
    }

    public void setListOfvehicles(List<Vehicle> listOfvehicles) {
        this.listOfvehicles = listOfvehicles;
    }

    public RatePlan getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(RatePlan ratePlan) {
        this.ratePlan = ratePlan;
    }
}

