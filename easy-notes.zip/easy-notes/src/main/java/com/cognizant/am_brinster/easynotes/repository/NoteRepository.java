package com.cognizant.am_brinster.easynotes.repository;

import com.cognizant.am_brinster.easynotes.entity.Notes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NoteRepository extends JpaRepository<Notes, Long> {
}
