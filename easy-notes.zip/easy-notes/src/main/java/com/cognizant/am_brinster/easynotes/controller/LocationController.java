package com.cognizant.am_brinster.easynotes.controller;


import com.cognizant.am_brinster.easynotes.entity.Location;
import com.cognizant.am_brinster.easynotes.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class LocationController {
    @Autowired
    LocationRepository locationRepository;

    @GetMapping("/getAllLocations")
    public List getAllLocations(){
        Object[] listOfLocationsObject =locationRepository.findAllLocations();
        if(listOfLocationsObject!=null){
            return Arrays.asList(listOfLocationsObject);
        }else{
            return  null;
        }



    }
}
