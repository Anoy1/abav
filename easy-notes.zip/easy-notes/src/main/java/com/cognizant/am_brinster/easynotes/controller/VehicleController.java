package com.cognizant.am_brinster.easynotes.controller;

import com.cognizant.am_brinster.easynotes.entity.Location;
import com.cognizant.am_brinster.easynotes.entity.Vehicle;
import com.cognizant.am_brinster.easynotes.repository.VehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class VehicleController {
    Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    VehicleRepository vehicleRepository;
    @GetMapping("/getVehiclesFor/{locationCode}")
    public List getVehicleForLocation(@PathVariable("locationCode") String locationCode){
        log.info("locationCode ==== > "+locationCode);
        //Location location = new Location(locationCode);
        Object[] listOfVehicleObject =vehicleRepository.findVehiclesByLocationCode(locationCode);
        if(listOfVehicleObject!=null){
            return Arrays.asList(listOfVehicleObject);
        }else{
            return  null;
        }

    }

}
