package com.cognizant.am_brinster.easynotes.entity;

import javax.persistence.*;

@Entity
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long vehicleID;
    @Column
    private String vehicleName;

    @Column
    private String vehicleDescription;

    @Column
    private long numberOfSeats;

    @Column
    private long numberOfAirBags;

    @ManyToOne
    @JoinColumn(name ="LocationCode")
    private Location location;


    @OneToOne(mappedBy = "vehicle")
    private RatePlan ratePlan;

    public Vehicle() {
    }

    public long getVehicleID() {
        return vehicleID;
    }

    public void setVehicleID(long vehicleID) {
        this.vehicleID = vehicleID;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public String getVehicleDescription() {
        return vehicleDescription;
    }

    public void setVehicleDescription(String vehicleDescription) {
        this.vehicleDescription = vehicleDescription;
    }

    public long getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(long numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public long getNumberOfAirBags() {
        return numberOfAirBags;
    }

    public void setNumberOfAirBags(long numberOfAirBags) {
        this.numberOfAirBags = numberOfAirBags;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public RatePlan getRatePlan() {
        return ratePlan;
    }

    public void setRatePlan(RatePlan ratePlan) {
        this.ratePlan = ratePlan;
    }
}
